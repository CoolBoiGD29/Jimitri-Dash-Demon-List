// Paste the config object Firebase gives you when you register a Web app
// (Project settings -> General -> Your apps -> the "</>" icon).
// It looks like this, just with your real values:
export const firebaseConfig = {
  apiKey: "PASTE_ME",
  authDomain: "PASTE_ME.firebaseapp.com",
  projectId: "PASTE_ME",
  storageBucket: "PASTE_ME.appspot.com",
  messagingSenderId: "PASTE_ME",
  appId: "PASTE_ME"
};
